'use strict';

// Define the `core.phone` module
angular.module('core.phone', ['ngResource']);
