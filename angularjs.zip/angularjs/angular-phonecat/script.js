var message1 = document.getElementById('message');
	message1.innerHTML = "Nothing here {{'yet' + '!'}}";